package com.learntodroid.switchingbetweenactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    Button backButton;
    TextView result;

    Button colorChangeButton;
    EditText userColorInput;
    Layout secondLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        colorChangeButton = findViewById(R.id.changebackgroundButton2);
        backButton = findViewById(R.id.activity_second_button);
        userColorInput = findViewById(R.id.usercolorInput);
        //findViewById(R.id.activity_second).;
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        colorChangeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userColor = userColorInput.getText().toString();
                try {
                    findViewById(R.id.activity_second).setBackgroundColor(Color.parseColor(userColor));
                } catch( RuntimeException e){

                }

                //findViewById(R.id.activity_second).setBackgroundColor(Color.parseColor(userColor));
            }
        });

//        retrieveMessage();
    }


//    private void retrieveMessage() {
//        result = findViewById(R.id.activity_second_result);
//        result.setText(getIntent().getStringExtra("message"));
//    }
}
