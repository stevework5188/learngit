package com.learntodroid.switchingbetweenactivities;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SumGameActivity extends AppCompatActivity {
    Button backButton;

    Button addButton;
    EditText num1;
    EditText num2;
    TextView sum;

//    @SuppressLint("MissingInflatedId")
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        addButton = findViewById(R.id.addButton);
        backButton = findViewById(R.id.activity_second_button2);
        num1 = findViewById(R.id.inputNum1);
        num2 = findViewById(R.id.inputNum2);
        sum = findViewById(R.id.resultSum);

        //findViewById(R.id.activity_second).;
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int result = Integer.parseInt(num1.getText().toString())+Integer.parseInt(num2.getText().toString());

                sum.setText(String.valueOf(result));


            }
        });

//        retrieveMessage();
    }


//    private void retrieveMessage() {
//        result = findViewById(R.id.activity_second_result);
//        result.setText(getIntent().getStringExtra("message"));
//    }
}
